#############################################
##  Dimension and Aspect Ratio Calculator  ##
##              (version 1.0)              ##
##            (c)Mevelar -- 2022           ##
#############################################


def div(width, height):
    """Returns num1 divided by num2."""
    try:
        return width / height
    except ZeroDivisionError:
        print("Handled div by zero. Returning zero.")
        return 0
        
def div2(height, width):
    """Returns num1 divided by num2."""
    try:
        return height / width
    except ZeroDivisionError:
        print("Handled div by zero. Returning zero.")
        return 0

def runOperation(new_dims, width, height,ar):

    """Determines the operation to run based on the 
    operation argument which should be passed in as an
    int"""
    # Determine operation
    if (new_dims * ' '):
        ar = width / height
        print("Calculating new values...")
        print("New height: ", (height / width)*new_dims)
        print("New width: ", ((height / width)*new_dims)*ar)
        print("Aspect ratio: ", ("{:.2f}".format(width / height)),":1")
    else:
        print("I don't understand")



def main():
    """Allows user to run basic calculator operations with two numbers."""
    validInput = False
    while not validInput:
        # Get user input
        try:
            width = int(input("What is the current width? "))
            height = int(input("What is the current height? "))
            # operation = int(input("What do you want to do? 4. divide."           
            ar = width / height
            new_dims = int(input("Enter new value (height or width): "
                                  ))
            validInput = True
        except ValueError:
            print("Invalid input. Try again.")
        except:
            print("Unknown error")
        runOperation(new_dims, width, height,ar)


if __name__ == "__main__":
    main()
Dimension and Aspect Ratio Calculator (version 1.0)

About the app
***************

This app recalculates the dimensions of an image. Just input the numeric value of the original Lenght AND Height followed by desired resize (Lenght OR Height). New values, along with the aspect ratio, will be the results. 

Copyright and License:
**********************

Copyright (c) 2022 Mevelar

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.



bl_info = {
    "name" : "Fast Mesh",
    "author" : "Mevelar",
    "version" : (1,0),
    "blender" : (2,93,0),
    "location" : "View3d > Tool",
    "warning" : "",
    "wiki_url" : "",
    "category" : "Mesh Edits",
}

import bpy  # main body

class PanelA(bpy.types.Panel): 
    bl_label = "Edit EDGES"
    bl_idname = "PT_PanelA"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'FastMesh'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text= "Select edge loop or edge ring.", icon = 'RADIOBUT_OFF')
        row = layout.row()
        row.operator("mesh.loop_multi_select", text= "EDGE LOOP or EDGE RING.")
        row = layout.row()
        row.label(text="Turn edge CW.", icon='LOOP_FORWARDS')
        row = layout.row()
        row.operator("mesh.edge_rotate", text="CW or CCW EDGE.")
        row = layout.row()
        row.label(text= "Slide edge.", icon = 'DECORATE_DRIVER')
        row = layout.row()
        row.operator("transform.edge_slide", text="EDGE SLIDE.")
        
        
class PanelB(bpy.types.Panel): 
    bl_label = "Resize Object"
    bl_idname = "PT_PanelB"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'NewTab'
    bl_parent_id = 'PT_PanelA'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        obj = context.object
        row = layout.row()
        row.label(text= "Scale object.", icon = 'CON_SIZELIMIT')
        row = layout.row()
        row.operator("transform.resize")
        row = layout.row()
        col = layout.column()
        col.prop(obj, "scale")


class PanelC(bpy.types.Panel): 
    bl_label = "Mesh Merge"
    bl_idname = "PT_PanelC"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'NewTab'
    bl_parent_id = 'PT_PanelA'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.label(text= "Select an option.", icon = 'COLOR_BLUE')
        row.operator("mesh.merge")


class PanelD(bpy.types.Panel): 
    bl_label = "Reset Origin"
    bl_idname = "PT_PanelD"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'NewTab'
    bl_parent_id = 'PT_PanelA'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        obj = context.object
        row = layout.row()
        row.label(text= "Reset cursor.", icon = 'EMPTY_ARROWS')
        row = layout.row()
        row.operator("view3d.snap_cursor_to_selected")
        row = layout.row()
        row.label(text= "Set new origin.", icon = 'OUTLINER_DATA_EMPTY')
        row = layout.row()
        row.operator("object.origin_set")

def register():
    bpy.utils.register_class(PanelA)
    bpy.utils.register_class(PanelB)
    bpy.utils.register_class(PanelC)
    bpy.utils.register_class(PanelD)
    

def unregister():
    bpy.utils.unregister_class(PanelA)
    bpy.utils.unregister_class(PanelB)
    bpy.utils.unregister_class(PanelC)
    bpy.utils.unregister_class(PanelD)
    
    
if __name__ == "__main__":
    register()


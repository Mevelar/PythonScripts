	                             Blender Fast Mesh editor (version 1.0)
	
	About the addon
	***************
	
	This is a Blender 2.93 addon that offers an easy access set of tools for editing
	mesh type objects.
	
	Copyright and License:
	**********************
	
	Copyright (c) 2022 Mevelar
	
	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	Get the latest edition of Fast Mesh editor:
	*******************************************
	
	To get the addon, either search for it in the blender addon tracker or check
	out the latest edition on github (https://github.com/Mevelar/BlenderAddOns).
	
	Installation:
	*************
	
	To install the addon, simply copy BlenderFastMesh.py into your addons directory by
	going to Edit => Blender Preferences => then clicking on the 'Add-ons' button located
	at the left of the screen. From there, locate the 'Install' button near the top right
	of the Blender Preferences window and find the directory where you downloaded the 
	BlenderFastMesh.py to. Once the addon has been installed, just enable it by clicking 
	on the checkbox.
	
		
	Links:
	******
	
	Get the Blender 3D suite at:
	http://blender.org
	
	
